
package stock;

public class Stock {


    public static void main(String[] args) {
        
      //  home b=new home();
        //b.setVisible(true);
        
       login a=new login();
       a.setVisible(true);
        
    //  suplier_insert sup1= new suplier_insert();
    //  sup1.setVisible(true);
        
        
        
        
    }
    
}
