package stock;

import java.sql.*;
import javax.swing.*;
class btn_config{
    public int r = 0;
    
    public  void btn_vld(int i){
    
       r = i;
       
    }
    public int btn_1(){
    return r;
    }
    
}
public class login extends javax.swing.JFrame {

    public login() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_name = new javax.swing.JLabel();
        txt_uname = new javax.swing.JTextField();
        lbl_type = new javax.swing.JLabel();
        txt_password = new javax.swing.JPasswordField();
        cmb_type = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btn_login = new javax.swing.JButton();
        btn_createacc = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lbl_spark = new javax.swing.JLabel();
        lbl_login = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        lbl_name.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lbl_name.setText("User Name:");

        txt_uname.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N

        lbl_type.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        lbl_type.setText("User Type:");

        txt_password.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N

        cmb_type.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        cmb_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Supplier Manager", "Stock Manager", "Employee" }));
        cmb_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_typeActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        jLabel1.setText("Password:");

        jPanel1.setBackground(new java.awt.Color(102, 255, 255));

        btn_login.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btn_login.setText("logIn");
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });

        btn_createacc.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btn_createacc.setText("Create Account");
        btn_createacc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_createaccActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(btn_login, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                .addComponent(btn_createacc, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_login, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_createacc, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(102, 255, 255));

        lbl_spark.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        lbl_spark.setText("Spark Electronics");

        lbl_login.setFont(new java.awt.Font("Tahoma", 0, 26)); // NOI18N
        lbl_login.setText("LogIn");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_spark, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(141, 141, 141))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(lbl_login)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_spark)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_login)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lbl_type, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lbl_name, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cmb_type, 0, 258, Short.MAX_VALUE)
                    .addComponent(txt_password)
                    .addComponent(txt_uname))
                .addGap(107, 107, 107))
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_name, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_uname, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cmb_type, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
                    .addComponent(lbl_type, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_password, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_createaccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_createaccActionPerformed
         this.setVisible(false);
        new register().setVisible(true);
    }//GEN-LAST:event_btn_createaccActionPerformed

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
          
        String entereduname= txt_uname.getText();
        String uname; 
        char[] pass = txt_password.getPassword();
        String enteredpassword = new String(pass);
        String password;
        int check=0;
        String enteredtype= (String)cmb_type.getSelectedItem();
        String type;
        try
        {
          String path="jdbc:mysql://localhost/stock";
          Connection con=DriverManager.getConnection(path,"root","");
          Statement s = con.createStatement();
          String query="SELECT * FROM users";
          ResultSet rs = s.executeQuery(query);
          
          while(rs.next())
          { 
            uname = rs.getString(1);
            type=rs.getString(2);
            password = rs.getString(6);
            
            if(uname.equals(entereduname)&& type.equals(enteredtype) && password.equals(enteredpassword))
            {
                check =1;
                break;
            }
          }
          
          if(check==0)
          {
              JOptionPane.showMessageDialog(this,"Not Found");
          }
          
          else if(check==1)
          {
                 if(enteredtype.equals("Supplier Manager"))
                     
        { //enteredtypee(enteredtype);
            btn_config A =new btn_config();
            A.btn_vld(1);
          this.setVisible(false);
          new mainhome().setVisible(true);
          
          
          
        }
        else if(enteredtype.equals("Stock Manager"))
        {//enteredtypee(enteredtype);
          this.setVisible(false);
          new mainhome2().setVisible(true);
          
          
        }
        else
        {//enteredtypee(enteredtype);
         this.setVisible(false);
         new mainhome3().setVisible(true);
         
        } 
                 
                 
                  
         }
 
    }
          catch(SQLException e)
        {
        
               JOptionPane.showMessageDialog(this, "Error occured"+e.getMessage(),"Information",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btn_loginActionPerformed

    private void cmb_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_typeActionPerformed

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_createacc;
    private javax.swing.JButton btn_login;
    private javax.swing.JComboBox<String> cmb_type;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbl_login;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel lbl_spark;
    private javax.swing.JLabel lbl_type;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_uname;
    // End of variables declaration//GEN-END:variables

    private void enteredtypee(String enteredtype) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

