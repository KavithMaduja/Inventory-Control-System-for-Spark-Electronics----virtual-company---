package stock;

import java.sql.*;
import javax.swing.*;

public class register extends javax.swing.JFrame {
    public register() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        lbl_name = new javax.swing.JLabel();
        txt_name = new javax.swing.JTextField();
        lbl_type = new javax.swing.JLabel();
        cmb_type = new javax.swing.JComboBox<>();
        lbl_nic = new javax.swing.JLabel();
        txt_nic = new javax.swing.JTextField();
        lbl_address = new javax.swing.JLabel();
        txt_address = new javax.swing.JTextField();
        lbl_mobile = new javax.swing.JLabel();
        txt_mobile = new javax.swing.JTextField();
        lbl_password = new javax.swing.JLabel();
        txt_password = new javax.swing.JPasswordField();
        lbl_confirm = new javax.swing.JLabel();
        txt_confirm = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        btn_register = new javax.swing.JButton();
        btn_login = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lbl_signup = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        lbl_name.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_name.setText("Name:");

        txt_name.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl_type.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_type.setText("User Type:");

        cmb_type.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cmb_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Supplier Manager", "Stock Manager", "Employee" }));

        lbl_nic.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_nic.setText("NIC:");

        txt_nic.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl_address.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_address.setText("Address:");

        txt_address.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl_mobile.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_mobile.setText("Mobile No:");

        txt_mobile.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl_password.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_password.setText("Password:");

        txt_password.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lbl_confirm.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbl_confirm.setText("Confirm Password:");

        txt_confirm.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(102, 255, 255));

        btn_register.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        btn_register.setText("Register");
        btn_register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registerActionPerformed(evt);
            }
        });

        btn_login.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        btn_login.setText("LogIn");
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(btn_register)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_login)
                .addGap(112, 112, 112))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_register, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_login, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(102, 255, 255));

        lbl_signup.setFont(new java.awt.Font("Tahoma", 0, 26)); // NOI18N
        lbl_signup.setText("SignUp");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(271, 271, 271)
                .addComponent(lbl_signup)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_signup)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_name)
                    .addComponent(lbl_type)
                    .addComponent(lbl_nic, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_address)
                    .addComponent(lbl_mobile)
                    .addComponent(lbl_confirm)
                    .addComponent(lbl_password))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_name)
                    .addComponent(txt_nic)
                    .addComponent(txt_mobile)
                    .addComponent(txt_address)
                    .addComponent(txt_password)
                    .addComponent(txt_confirm)
                    .addComponent(cmb_type, 0, 331, Short.MAX_VALUE))
                .addGap(43, 43, 43))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_name)
                    .addComponent(txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_type)
                    .addComponent(cmb_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_nic)
                    .addComponent(txt_nic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_address)
                    .addComponent(txt_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_mobile)
                    .addComponent(txt_mobile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_password)
                    .addComponent(txt_password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_confirm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_confirm))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getAccessibleContext().setAccessibleName("frm_signup");
        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registerActionPerformed
        String name=txt_name.getText();
        String type=(String) cmb_type.getSelectedItem();
          String nic=txt_nic.getText();
          String address=txt_address.getText();
          String mobile=txt_mobile.getText();
          String password=txt_password.getText();
          String confirm=txt_confirm.getText();
          
        if(name.equals(""))
        {
            JOptionPane.showMessageDialog(this,"name cannot be blank","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(nic.equals(""))
        {
            JOptionPane.showMessageDialog(this,"NIC No cannot be blank","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(nic.length()!=10 && nic.length()!=12)
        {
           JOptionPane.showMessageDialog(this,"NIC No Invalid","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(address.equals(""))
        {
           JOptionPane.showMessageDialog(this,"Address cannot be blank","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(mobile.equals(""))
        {
           JOptionPane.showMessageDialog(this,"Mobile No Invalid","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(mobile.length()!=10)
        {
           JOptionPane.showMessageDialog(this,"Mobile No Invalid","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        /*else if(NumberUtils.isNumber(mobile));
        {
           JOptionPane.showMessageDialog(this,"Mobile No should be numeric","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        */
        else if (password.equals(""))
        {
           JOptionPane.showMessageDialog(this,"Password cannot be blank","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(confirm.equals(""))
        {
           JOptionPane.showMessageDialog(this,"confirm Password cannot be blank","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(!(password.equals(confirm)))
        {
           JOptionPane.showMessageDialog(this,"Passwords do not match","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        else
        {
        try
        {
          String path="jdbc:mysql://localhost/stock";
          Connection con=DriverManager.getConnection(path,"root","");
          PreparedStatement pst=con.prepareStatement("insert into Users values(?,?,?,?,?,?)");
          pst.setString(1,txt_name.getText());
          pst.setString(2, (String) cmb_type.getSelectedItem());
          pst.setString(3,txt_nic.getText());
          pst.setString(4,txt_address.getText());
          pst.setString(5,txt_mobile.getText());
          pst.setString(6,txt_confirm.getText());
       pst.execute();
          JOptionPane.showMessageDialog(null, "Registered");
      
        }
        catch(SQLException e)
        {
        
          JOptionPane.showMessageDialog(this, "Error occured"+e.getMessage(),"Information",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btn_registerActionPerformed
    }
    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
        this.setVisible(false);
        new home1().setVisible(true);
    }//GEN-LAST:event_btn_loginActionPerformed
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new register().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_login;
    private javax.swing.JButton btn_register;
    private javax.swing.JComboBox<String> cmb_type;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lbl_address;
    private javax.swing.JLabel lbl_confirm;
    private javax.swing.JLabel lbl_mobile;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel lbl_nic;
    private javax.swing.JLabel lbl_password;
    private javax.swing.JLabel lbl_signup;
    private javax.swing.JLabel lbl_type;
    private javax.swing.JTextField txt_address;
    private javax.swing.JPasswordField txt_confirm;
    private javax.swing.JTextField txt_mobile;
    private javax.swing.JTextField txt_name;
    private javax.swing.JTextField txt_nic;
    private javax.swing.JPasswordField txt_password;
    // End of variables declaration//GEN-END:variables
}
